import React, { Component } from 'react';
import EmployeeService from '../services/EmployeeService';
import { Link } from 'react-router-dom';
import '../App.css'
export default class ListEmployeeComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [],
            error: null, // For error handling
            loading: true // Loading state
        };
    }

    componentDidMount() {
        this.fetchEmployees();
    }

    fetchEmployees = () => {
        EmployeeService.getEmployees()
            .then((res) => {
                this.setState({ employees: res.data, loading: false });
            })
            .catch((error) => {
                console.error("Error fetching employees:", error);
                this.setState({ error: "Error fetching employee data", loading: false });
            });
    };

    deleteEmployee = (employeeId) => {
        EmployeeService.deleteEmployee(employeeId)
            .then(() => {
                this.fetchEmployees(); // Fetch updated employee list after deletion
            })
            .catch((error) => {
                console.error("Error deleting employee:", error);
            });
    };

    render() {
        const { employees, error, loading } = this.state;

        return (
            <div>
                <h2 className='text-center'>Employee List</h2>

                <div className='row'>
                    <Link to="/add-employee" className='btn btn-outline-primary mt-4 w-100'>Add Employee</Link>

                    {loading ? (
                        <p>Loading employees...</p> // Loading message
                    ) : error ? (
                        <p className="text-danger">{error}</p> // Display error message
                    ) : (
                        <table className='table table-striped table-bordered'>
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {employees.map((employee) => (
                                    <tr key={employee.id}>
                                        <td>{employee.firstName}</td>
                                        <td>{employee.lastName}</td>
                                        <td>{employee.email}</td>
                                        <td>
                                            <Link to={`/update-employee/${employee.id}`} className="btn btn-info">Update</Link>
                                            <button
                                                className='btn btn-danger'
                                                style={{ marginLeft: "15px" }}
                                                onClick={() => this.deleteEmployee(employee.id)}
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        );
    }
}
